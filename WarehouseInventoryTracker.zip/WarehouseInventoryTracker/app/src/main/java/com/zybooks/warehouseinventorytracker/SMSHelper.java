
package com.zybooks.warehouseinventorytracker;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class SMSHelper {

    private static final String TAG = "SMS_DEBUG";

    // Send alerts only when SMS notifications are enabled.
    public static boolean sendLowInventoryAlert(
            Context context, String itemName, int quantity) {

        SharedPreferences preferences =
                context.getSharedPreferences(
                        "SMSSettings", Context.MODE_PRIVATE);

        boolean enabled = preferences.getBoolean("enabled", false);
        String phone = preferences.getString("phone", "");

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        context, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED;

        if (!enabled || phone == null || phone.trim().isEmpty()
                || !permissionGranted) {
            Log.w(TAG, "SMS skipped: settings or permission");
            return false;
        }

        String message = "Warehouse Inventory Alert: " +
                itemName + " is running low. Only " +
                quantity + " units remaining.";

        try {
            SmsManager smsManager =
                    context.getSystemService(SmsManager.class);

            if (smsManager == null) {
                Log.e(TAG, "SMS Manager unavailable");
                return false;
            }

            Context appContext = context.getApplicationContext();

            String sentAction =
                    context.getPackageName() + ".SMS_SENT";

            String deliveredAction =
                    context.getPackageName() + ".SMS_DELIVERED";

            BroadcastReceiver sentReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context receiverContext,
                                      Intent intent) {

                    int result = getResultCode();

                    if (result == Activity.RESULT_OK) {
                        Log.d(TAG, "SMS sent successfully");
                    } else {
                        Log.e(TAG, "SMS send failed: " + result);
                    }

                    try {
                        appContext.unregisterReceiver(this);
                    } catch (IllegalArgumentException e) {
                        Log.w(TAG, "Sent receiver already removed");
                    }
                }
            };

            BroadcastReceiver deliveredReceiver =
                    new BroadcastReceiver() {
                        @Override
                        public void onReceive(Context receiverContext,
                                              Intent intent) {

                            int result = getResultCode();

                            if (result == Activity.RESULT_OK) {
                                Log.d(TAG, "SMS delivered successfully");
                            } else {
                                Log.e(TAG, "SMS delivery failed: " + result);
                            }

                            try {
                                appContext.unregisterReceiver(this);
                            } catch (IllegalArgumentException e) {
                                Log.w(TAG, "Delivery receiver already removed");
                            }
                        }
                    };

            ContextCompat.registerReceiver(
                    appContext,
                    sentReceiver,
                    new IntentFilter(sentAction),
                    ContextCompat.RECEIVER_NOT_EXPORTED
            );

            ContextCompat.registerReceiver(
                    appContext,
                    deliveredReceiver,
                    new IntentFilter(deliveredAction),
                    ContextCompat.RECEIVER_NOT_EXPORTED
            );

            Intent sentIntent = new Intent(sentAction);
            sentIntent.setPackage(context.getPackageName());

            Intent deliveredIntent = new Intent(deliveredAction);
            deliveredIntent.setPackage(context.getPackageName());

            PendingIntent sentPendingIntent =
                    PendingIntent.getBroadcast(
                            context,
                            0,
                            sentIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT |
                                    PendingIntent.FLAG_MUTABLE
                    );

            PendingIntent deliveredPendingIntent =
                    PendingIntent.getBroadcast(
                            context,
                            1,
                            deliveredIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT |
                                    PendingIntent.FLAG_MUTABLE
                    );

            Log.d(TAG, "Attempting SMS to: " + phone);

            smsManager.sendTextMessage(
                    phone,
                    null,
                    message,
                    sentPendingIntent,
                    deliveredPendingIntent
            );

            return true;

        } catch (Exception e) {
            Log.e(TAG, "SMS exception", e);
            return false;
        }
    }
}
