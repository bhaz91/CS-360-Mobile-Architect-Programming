package com.zybooks.warehouseinventorytracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect the Java variables to the login screen.
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Initialize the SQLite database helper.
        databaseHelper = new DatabaseHelper(this);

        // Handle the Login button.
        buttonLogin.setOnClickListener(v -> loginUser());

        // Handle the Create Account button.
        buttonCreateAccount.setOnClickListener(v -> createAccount());
    }

    // Verify the username and password.
    private void loginUser() {

        String username = editTextUsername.getText()
                .toString().trim();

        String password = editTextPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.checkLogin(username, password)) {

            Toast.makeText(this,
                    "Login successful!",
                    Toast.LENGTH_SHORT).show();

            // Open the inventory screen.
            Intent intent = new Intent(
                    MainActivity.this,
                    InventoryActivity.class
            );

            startActivity(intent);
            finish();

        } else {

            Toast.makeText(this,
                    "Invalid username or password",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Create and save a new account.
    private void createAccount() {

        String username = editTextUsername.getText()
                .toString().trim();

        String password = editTextPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 8) {
            Toast.makeText(this,
                    "Password must be at least 8 characters",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.createUser(
                username, password);

        if (success) {

            Toast.makeText(this,
                    "Account created! You can now log in.",
                    Toast.LENGTH_LONG).show();

            editTextPassword.setText("");

        } else {

            Toast.makeText(this,
                    "Username already exists or account creation failed",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        super.onDestroy();
    }
}
