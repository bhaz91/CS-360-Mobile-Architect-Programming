package com.zybooks.warehouseinventorytracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText editTextItemName;
    private EditText editTextQuantity;
    private TableLayout tableInventory;
    private TextView textLowInventoryAlert;

    private static final int LOW_STOCK_LIMIT = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    101);
        }

        databaseHelper = new DatabaseHelper(this);

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        tableInventory = findViewById(R.id.tableInventory);
        textLowInventoryAlert =
                findViewById(R.id.textLowInventoryAlert);

        Button buttonAddItem = findViewById(R.id.buttonAddItem);

        buttonAddItem.setOnClickListener(v -> addInventoryItem());

        Button buttonSMSSettings = findViewById(R.id.buttonSMSSettings);

        buttonSMSSettings.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this, SMSActivity.class);
            startActivity(intent);
        });

        // Display existing records when the screen opens.
        displayInventory();
    }

    // Save a new inventory item to SQLite.
    private void addInventoryItem() {
        String name = editTextItemName.getText()
                .toString().trim();

        String quantityText = editTextQuantity.getText()
                .toString().trim();

        if (name.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this,
                    "Enter an item name and quantity",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this,
                    "Enter a valid quantity",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.addItem(name, quantity);

        if (success) {
            Toast.makeText(this,
                    "Item added successfully",
                    Toast.LENGTH_SHORT).show();


            if (quantity < LOW_STOCK_LIMIT) {

                // Display a local low-inventory notification.
                NotificationHelper.showLowStockNotification(
                        this, name, quantity);

                // Also attempt SMS when enabled and permitted.
                SMSHelper.sendLowInventoryAlert(
                        this, name, quantity);
            }



            editTextItemName.setText("");
            editTextQuantity.setText("");

            displayInventory();
        } else {
            Toast.makeText(this,
                    "Unable to add item",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Refresh the inventory table using saved database records.
    private void displayInventory() {

        // Keep the header row and remove previous item rows.
        if (tableInventory.getChildCount() > 1) {
            tableInventory.removeViews(
                    1, tableInventory.getChildCount() - 1);
        }

        StringBuilder lowStockItems = new StringBuilder();

        try (Cursor cursor = databaseHelper.getAllItems()) {

            while (cursor.moveToNext()) {

                int id = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int quantity = cursor.getInt(2);

                TableRow row = new TableRow(this);
                row.setPadding(4, 8, 4, 8);

                TextView nameView = new TextView(this);
                nameView.setText(itemName);
                nameView.setTextColor(0xFF212121);
                nameView.setPadding(4, 8, 4, 8);

                TextView quantityView = new TextView(this);
                quantityView.setText(String.valueOf(quantity));
                quantityView.setTextColor(0xFF212121);
                quantityView.setPadding(4, 8, 4, 8);

                Button editButton = new Button(this);
                editButton.setText("Edit");

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");

                // Place both action buttons in one table cell.
                android.widget.LinearLayout actions =
                        new android.widget.LinearLayout(this);
                actions.setOrientation(
                        android.widget.LinearLayout.VERTICAL);

                actions.addView(editButton);
                actions.addView(deleteButton);

                row.addView(nameView);
                row.addView(quantityView);
                row.addView(actions);

                tableInventory.addView(row);

                editButton.setOnClickListener(
                        v -> showEditDialog(id, itemName, quantity));

                deleteButton.setOnClickListener(
                        v -> confirmDelete(id, itemName));

                // Identify items that need restocking.
                if (quantity < LOW_STOCK_LIMIT) {
                    if (lowStockItems.length() > 0) {
                        lowStockItems.append(", ");
                    }
                    lowStockItems.append(itemName);
                }
            }
        }

        if (lowStockItems.length() > 0) {
            textLowInventoryAlert.setText(
                    "Low Inventory Alert: " + lowStockItems);
            textLowInventoryAlert.setVisibility(View.VISIBLE);
        } else {
            textLowInventoryAlert.setVisibility(View.GONE);
        }
    }

    // Allow users to change an item's quantity.
    private void showEditDialog(int id, String name, int quantity) {

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(quantity));
        input.setSelectAllOnFocus(true);

        new AlertDialog.Builder(this)
                .setTitle("Update " + name)
                .setMessage("Enter the new quantity:")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {

                    try {
                        int newQuantity = Integer.parseInt(
                                input.getText().toString().trim());

                        if (databaseHelper.updateItem(id, newQuantity)) {

                            Toast.makeText(this,
                                    "Quantity updated",
                                    Toast.LENGTH_SHORT).show();

                            // Send an alert when stock crosses below the threshold.

                            if (newQuantity < LOW_STOCK_LIMIT
                                    && quantity >= LOW_STOCK_LIMIT) {

                                NotificationHelper.showLowStockNotification(
                                        this, name, newQuantity);

                                SMSHelper.sendLowInventoryAlert(
                                        this, name, newQuantity);
                            }


                            displayInventory();
                        }

                         else {
                            Toast.makeText(this,
                                    "Unable to update item",
                                    Toast.LENGTH_SHORT).show();
                        }

                    } catch (NumberFormatException e) {
                        Toast.makeText(this,
                                "Enter a valid quantity",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Confirm before permanently deleting an item.
    private void confirmDelete(int id, String name) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Delete " + name + " from inventory?")
                .setPositiveButton("Delete", (dialog, which) -> {

                    if (databaseHelper.deleteItem(id)) {
                        Toast.makeText(this,
                                "Item deleted",
                                Toast.LENGTH_SHORT).show();
                        displayInventory();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        super.onDestroy();
    }
}
