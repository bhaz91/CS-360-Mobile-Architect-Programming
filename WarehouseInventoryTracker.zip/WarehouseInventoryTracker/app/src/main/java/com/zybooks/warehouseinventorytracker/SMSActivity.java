package com.zybooks.warehouseinventorytracker;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private EditText editTextPhone;
    private SwitchCompat switchSMS;
    private TextView textSMSStatus;
    private SharedPreferences preferences;

    private ActivityResultLauncher<String> permissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        editTextPhone = findViewById(R.id.editTextPhone);
        switchSMS = findViewById(R.id.switchSMS);
        textSMSStatus = findViewById(R.id.textSMSStatus);

        Button buttonSMSPermission =
                findViewById(R.id.buttonSMSPermission);
        Button buttonBackInventory =
                findViewById(R.id.buttonBackInventory);

        // Save SMS preferences between app sessions.
        preferences = getSharedPreferences(
                "SMSSettings", Context.MODE_PRIVATE);

        editTextPhone.setText(
                preferences.getString("phone", ""));

        switchSMS.setChecked(
                preferences.getBoolean("enabled", false));

        // Handle the user's permission response.
        permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    if (granted) {
                        Toast.makeText(this,
                                "SMS permission granted",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this,
                                "SMS permission denied",
                                Toast.LENGTH_SHORT).show();
                    }
                    updateStatus();
                });

        buttonSMSPermission.setOnClickListener(v -> {
            permissionLauncher.launch(Manifest.permission.SEND_SMS);
        });

        switchSMS.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {
                    preferences.edit()
                            .putBoolean("enabled", isChecked)
                            .apply();
                    updateStatus();
                });

        buttonBackInventory.setOnClickListener(v -> {
            savePhoneNumber();
            finish();
        });

        updateStatus();
    }

    private void savePhoneNumber() {
        String phone = editTextPhone.getText()
                .toString().trim();

        preferences.edit()
                .putString("phone", phone)
                .apply();
    }

    private void updateStatus() {

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED;

        boolean enabled = switchSMS.isChecked();

        if (permissionGranted && enabled) {
            textSMSStatus.setText("SMS alerts are enabled.");
        } else if (!permissionGranted) {
            textSMSStatus.setText(
                    "SMS permission is not granted.");
        } else {
            textSMSStatus.setText("SMS alerts are disabled.");
        }
    }
}
