package com.zybooks.warehouseinventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.nio.charset.StandardCharsets;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WarehouseInventory.db";
    private static final int DATABASE_VERSION = 1;

    private static final String USERS_TABLE = "users";
    private static final String INVENTORY_TABLE = "inventory";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the user account table.
        db.execSQL("CREATE TABLE " + USERS_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "salt TEXT NOT NULL)");

        // Create the inventory table.
        db.execSQL("CREATE TABLE " + INVENTORY_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        // Future database upgrades will be handled here.
    }

    // Convert bytes into a hexadecimal string.
    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();

        for (byte b : bytes) {
            result.append(String.format("%02x", b & 0xff));
        }

        return result.toString();
    }

    // Hash a password with a unique salt.
    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] data = (salt + password)
                    .getBytes(StandardCharsets.UTF_8);

            return bytesToHex(digest.digest(data));
        } catch (Exception e) {
            throw new IllegalStateException("Unable to hash password", e);
        }
    }

    // Create a new user account.
    public boolean createUser(String username, String password) {

        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            return false;
        }

        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);

        String salt = bytesToHex(saltBytes);
        String passwordHash = hashPassword(password, salt);

        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash", passwordHash);
        values.put("salt", salt);

        SQLiteDatabase db = getWritableDatabase();

        long result = db.insertWithOnConflict(
                USERS_TABLE,
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
        );

        return result != -1;
    }

    // Check a user's login credentials.
    public boolean checkLogin(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                USERS_TABLE,
                new String[]{"password_hash", "salt"},
                "username = ?",
                new String[]{username.trim()},
                null, null, null)) {

            if (cursor.moveToFirst()) {
                String savedHash = cursor.getString(0);
                String salt = cursor.getString(1);
                String enteredHash = hashPassword(password, salt);

                return MessageDigest.isEqual(
                        savedHash.getBytes(StandardCharsets.UTF_8),
                        enteredHash.getBytes(StandardCharsets.UTF_8)
                );
            }
        }

        return false;
    }

    // Add a new inventory item.
    public boolean addItem(String itemName, int quantity) {

        if (itemName == null || itemName.trim().isEmpty()
                || quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);

        long result = getWritableDatabase().insert(
                INVENTORY_TABLE, null, values);

        return result != -1;
    }

    // Update an existing inventory item's quantity.
    public boolean updateItem(int id, int quantity) {

        if (quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("quantity", quantity);

        int rows = getWritableDatabase().update(
                INVENTORY_TABLE,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return rows > 0;
    }

    // Delete an inventory item.
    public boolean deleteItem(int id) {

        int rows = getWritableDatabase().delete(
                INVENTORY_TABLE,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        return rows > 0;
    }

    // Retrieve all inventory items for display.
    public Cursor getAllItems() {

        return getReadableDatabase().query(
                INVENTORY_TABLE,
                new String[]{"id", "item_name", "quantity"},
                null, null, null, null,
                "item_name ASC"
        );
    }
}
